export default {
  _widgetLabel: "Pictometry",
  latLon: "Lat/Lon",
  zoom: "Zoom",
  latLonWillBeHere: "Lat/Lon (None - please mouse over map)"
};
