export default {
  selectMapWidget: "Select Map Widget",
  settings: "Settings",
  showScale: "Show Scale",
  showZoom: "Show Zoom",
  showTilt: "Show Tilt",
  showRotation: "Show Rotation"
};
