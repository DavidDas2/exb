export default {
  _widgetLabel: "Google Maps",
  latLon: "Lat/Lon",
  zoom: "Zoom",
  latLonWillBeHere: "Lat/Lon (None - please mouse over map)"
};
